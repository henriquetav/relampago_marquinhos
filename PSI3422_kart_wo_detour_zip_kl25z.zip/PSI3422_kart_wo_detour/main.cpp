//Receiver code

#include "mbed.h"
#include <math.h>
#include "stdio.h"
#include <algorithm>
#include "nRF24L01P.h"
#include "HCSR04.h"

#define PULSES_PER_TURN             16      //pulses
#define KART_WIDTH                  17      //cm
#define WHEELS_DIAMETER             8       //cm
#define TRANSFER_SIZE               8       //byte
#define RF_FREQUENCY                2457    //MHz
#define SAFE_DISTANCE               30      //cm
#define DETOURING_DISTANCE          20      //cm
#define PWM_PERIOD                  0.0001f   //s
#define PWM_DUTY                    0.95f     //%
#define M_PI                        3.14159265358979323846
#define ERROR                       1E-16
#define NUM_LEITURAS                9       // Aquisições do ultrassom

void count_A(void);
void count_B(void);
void stop(void);
void move(int x, int y);
bool obstacle_ahead(void);
void detour(void);
void go_foward(int dist);
//void go_back(int dist);
void turn_left(void);
void turn_right(void);
void turn_back(void);

Serial pc(USBTX, USBRX); // tx, rx
nRF24L01P my_nrf24l01p(D11, D12, PTC5, D10, D9, D8);    // MOSI (PTD2), MISO (PTD3), SCK (PTC5), CSN (PTD0), CE (PTD5), IRQ (PTA13)
HCSR04 my_hcsr04(PTB9, PTB8);    // TRIG (PTB9), ECHO (PTB8)
DigitalOut myled1(LED1, 1); DigitalOut myled2(LED2, 1); DigitalOut myled3(LED3, 1);
PwmOut IN1(D5); //PTA5
PwmOut IN2(D4); //PTA4
PwmOut IN3(D3); //PTA12
PwmOut IN4(D2); //PTD4
InterruptIn encoder_A(PTD6); InterruptIn encoder_B(PTD7); //Habilitados em PullDown
volatile int COUNT_A = 0; volatile  int COUNT_B = 0; float DISTANCE_PER_PULSE;

int main() {
    // The nRF24L01+ supports transfers from 1 to 32 bytes, but Sparkfun's
    //  "Nordic Serial Interface Board" (http://www.sparkfun.com/products/9019)
    //  only handles 4 byte transfers in the ATMega code.

    DISTANCE_PER_PULSE = (2.0 * M_PI / PULSES_PER_TURN) * (WHEELS_DIAMETER / 2.0);

    my_nrf24l01p.powerUp();
    my_nrf24l01p.setRfFrequency(RF_FREQUENCY);
    my_nrf24l01p.setTransferSize( TRANSFER_SIZE );
    my_nrf24l01p.setReceiveMode();

    IN1.period(PWM_PERIOD); IN1.write(PWM_DUTY);
    IN2.period(PWM_PERIOD); IN2.write(PWM_DUTY);
    IN3.period(PWM_PERIOD); IN3.write(PWM_DUTY);
    IN4.period(PWM_PERIOD); IN3.write(PWM_DUTY);
    IN1 = 0;    IN2 = 0;    IN3 = 0;    IN4 = 0;
    encoder_A.rise(&count_A); encoder_A.fall(&count_A); //desvia para a iqr com borda de subida e a iqr com a borda de descida
    encoder_B.rise(&count_B); encoder_B.fall(&count_B); //desvia para a iqr com borda de subida e a iqr com a borda de descida
    
    // LEDs to mark initialization
    for (int i = 0; i < 5; i++) {
        myled1 = 0;    myled2 = 1;    myled3 = 1;
        wait_ms(100);
        myled1 = 1;    myled2 = 0;    myled3 = 1;
        wait_ms(100);
        myled1 = 1;    myled2 = 1;    myled3 = 0;
    }
    myled1 = 1;    myled2 = 1;    myled3 = 1;
    
    // Display the (default) setup of the nRF24L01+ chip
    pc.printf( "nRF24L01+ Frequency    : %d MHz\r\n",  my_nrf24l01p.getRfFrequency() );
    pc.printf( "nRF24L01+ Output power : %d dBm\r\n",  my_nrf24l01p.getRfOutputPower() );
    pc.printf( "nRF24L01+ Data Rate    : %d kbps\r\n", my_nrf24l01p.getAirDataRate() );
    pc.printf( "nRF24L01+ TX Address   : 0x%010llX\r\n", my_nrf24l01p.getTxAddress() );
    pc.printf( "nRF24L01+ RX Address   : 0x%010llX\r\n", my_nrf24l01p.getRxAddress() );
    pc.printf( "DISTANCE_PER_PULSE     = %.2f\r\n", DISTANCE_PER_PULSE);
    my_nrf24l01p.enable();
    
    char rxData[TRANSFER_SIZE];
    int x, y;
    while(true) {
        // If we've received anything in the nRF24L01+...
        if ( my_nrf24l01p.readable() ) {
            // ...read the data into the receive buffer
            my_nrf24l01p.read(NRF24L01P_PIPE_P0, rxData, TRANSFER_SIZE);
            char aux[3];
            aux[0] = rxData[1]; aux[1] = rxData[2]; aux[2] = rxData[3];
            sscanf(aux, "%d", &x);
            aux[0] = rxData[5]; aux[1] = rxData[6]; aux[2] = rxData[7];
            sscanf(aux, "%d", &y);
            if (rxData[0] == '-') x = -x;
            if (rxData[4] == '-') y = -y;
            pc.printf("Coordenadas recebidas: (%d, %d)\r\n", x, y);
            move(x,y);
        }
    }
}

void count_A(void) {COUNT_A++; wait_ms(10);}  //Incrementa contador
void count_B(void) {COUNT_B++; wait_ms(10);}  //Incrementa contador
void stop(void) {
    IN1 = 0;    IN2 = 0;    IN3 = 0;    IN4 = 0;
}
void move(int x, int y) {
    if (x != 0) {
        if (x < 0) {
            turn_back(); 
            y = -y; 
            wait_ms(10);
        }        
        go_foward(x);
    }
    if (y != 0) {
        if (y < 0) turn_left();
        else       turn_right();
        wait_ms(10);
        go_foward(y);
    }
    stop();
    pc.printf("Cheguei\r\n\r\n");
}
bool obstacle_ahead(void) {
    float distance[9];
    for (int i = 0; i < NUM_LEITURAS; i++) {
        my_hcsr04.readEcho();
        distance[i] = my_hcsr04.getCm();
    }
    std::sort(distance,distance+NUM_LEITURAS);
    int index = ceil(NUM_LEITURAS/2.0);
    if (distance[index] <= SAFE_DISTANCE) {
        pc.printf("\tObstaculo encontrado a %.2f cm de distancia!\r\n", distance[index]);
        return true;
    } else 
        return false;
}
void detour (void) {
    int COUNT_A_AUX = COUNT_A; int COUNT_B_AUX = COUNT_B;
    pc.printf("\tDesviando\r\n");       pc.printf("\t");
    turn_right();                       pc.printf("\t");
    go_foward(DETOURING_DISTANCE);      pc.printf("\t");
    turn_left();                        pc.printf("\t");
    COUNT_A = COUNT_A_AUX; COUNT_B = COUNT_B_AUX;
    go_foward(DETOURING_DISTANCE);      pc.printf("\t");
    COUNT_A_AUX = COUNT_A; COUNT_B_AUX = COUNT_B;
    turn_left();                        pc.printf("\t");
    go_foward(DETOURING_DISTANCE);      pc.printf("\t");
    turn_right();
    pc.printf("\tRetornando\r\n");
    COUNT_A = COUNT_A_AUX; COUNT_B = COUNT_B_AUX;
}
void go_foward(int dist) {
    int PULSES_TO_COUNT = (int) abs(dist) / DISTANCE_PER_PULSE;
    pc.printf("\tIndo em frente: ");
    COUNT_A = 0; COUNT_B = 0;
    while(COUNT_A <= PULSES_TO_COUNT && COUNT_B <= PULSES_TO_COUNT) {
        IN1 = 0;    IN2 = 1;    IN3 = 0;    IN4 = 1;
        pc.printf("%06.2f cm\b\b\b\b\b\b\b\b\b", DISTANCE_PER_PULSE * (COUNT_A + COUNT_B) / 2.0);
        wait_ms(50);
        //if (obstacle_ahead()) {
        //    pc.printf("\r\n");
        //    pc.printf("Obstaculo encontrado");
        //    detour();
        //}
    }
    pc.printf("\r\n"); 
    stop();
}
void turn_left(void) {
    int PULSES_TO_COUNT = (int) ((M_PI/2) * (KART_WIDTH/2.0)) / DISTANCE_PER_PULSE;
    pc.printf("\tVirando para esquerda\r\n");
    COUNT_A = 0; COUNT_B = 0;
    while(COUNT_A <= PULSES_TO_COUNT && COUNT_B <= PULSES_TO_COUNT) {
        IN1 = 0;    IN2 = 1;    IN3 = 1;    IN4 = 0;
    }
    stop();
}
void turn_right(void) {
    int PULSES_TO_COUNT = (int) ((M_PI/2) * (KART_WIDTH/2.0)) / DISTANCE_PER_PULSE;
    pc.printf("\tVirando para direita\r\n");
    COUNT_A = 0; COUNT_B = 0;
    while(COUNT_A <= PULSES_TO_COUNT && COUNT_B <= PULSES_TO_COUNT) {
        IN1 = 1;    IN2 = 0;    IN3 = 0;    IN4 = 1;
    }
    stop();
}
void turn_back(void) {
    int PULSES_TO_COUNT = (int) ((M_PI) * (KART_WIDTH/2.0)) / DISTANCE_PER_PULSE;
    pc.printf("\tVirando para tras\r\n");
    COUNT_A = 0; COUNT_B = 0;
    while(COUNT_A <= PULSES_TO_COUNT && COUNT_B <= PULSES_TO_COUNT) {
        IN1 = 1;    IN2 = 0;    IN3 = 0;    IN4 = 1;
    }
    stop();
}