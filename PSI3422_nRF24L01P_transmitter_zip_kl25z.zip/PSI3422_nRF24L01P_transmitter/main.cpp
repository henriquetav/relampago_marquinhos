//Item 1: O próprio código

#include "mbed.h"
#include "nRF24L01P.h"

Serial pc(USBTX, USBRX); // tx, rx

nRF24L01P my_nrf24l01p(D11, D12, PTC5, D10, D9, D8);    // MOSI (PTD2), MISO (PTD3), SCK (PTC5), CSN (PTD0), CE (PTD5), IRQ (PTA13)

DigitalOut myled3(LED3);

int main() {

// The nRF24L01+ supports transfers from 1 to 32 bytes, but Sparkfun's
//  "Nordic Serial Interface Board" (http://www.sparkfun.com/products/9019)
//  only handles 4 byte transfers in the ATMega code.
#define TRANSFER_SIZE   1
#define RF_FREQUENCY    2459

    char txData[TRANSFER_SIZE];
    int txDataCnt = 0;

    my_nrf24l01p.powerUp();
    
    // Estabelece a frequência de comunicação em RF_FREQUENCY MHz (arbitrário)
    my_nrf24l01p.setRfFrequency(RF_FREQUENCY);
    
    // Display the (default) setup of the nRF24L01+ chip
    pc.printf( "nRF24L01+ Frequency    : %d MHz\r\n",  my_nrf24l01p.getRfFrequency() );
    pc.printf( "nRF24L01+ Output power : %d dBm\r\n",  my_nrf24l01p.getRfOutputPower() );
    pc.printf( "nRF24L01+ Data Rate    : %d kbps\r\n", my_nrf24l01p.getAirDataRate() );
    pc.printf( "nRF24L01+ TX Address   : 0x%010llX\r\n", my_nrf24l01p.getTxAddress() );
    pc.printf( "nRF24L01+ RX Address   : 0x%010llX\r\n", my_nrf24l01p.getRxAddress() );

    pc.printf( "Type keys to test transfers:\r\n  (transfers are grouped into %d characters)\r\n", TRANSFER_SIZE );

    my_nrf24l01p.setTransferSize(TRANSFER_SIZE);

    my_nrf24l01p.setTransmitMode();
    my_nrf24l01p.enable();

    //myled1 = 1;
    //myled2 = 1;
    myled3 = 1;
    
    while (1) {

        // If we've received anything over the host serial link...
        if ( pc.readable() ) {

            // ...add it to the transmit buffer
            txData[txDataCnt++] = pc.getc();

            // If the transmit buffer is full
            if ( txDataCnt >= sizeof( txData ) ) {

                // Send the transmit buffer via the nRF24L01+
                my_nrf24l01p.write( NRF24L01P_PIPE_P0, txData, txDataCnt );
                pc.printf("Command send: ");
                //for ( int i = 0; txDataCnt > 0; txDataCnt--, i++ ) {
                //    pc.putc( txData[i] );
                //}
                pc.printf("%s",txData);
                pc.printf("\n\r");
                txDataCnt = 0;
                
                // Blink the blue LED
                myled3 = 0;
                wait(0.2);
                myled3 = 1;
            }
        }
    }
}

//site:
// https://edisciplinas.usp.br/pluginfile.php/7257439/mod_resource/content/2/Aula%201%20-%20Wireless%20nRF24L01.pdf
// https://os.mbed.com/platforms/KL25Z/
// https://blog.filipeflop.com/blog/motor-dc-arduino-ponte-h-l298n/
