//Receiver code

#include "mbed.h"
#include "nRF24L01P.h"

Serial pc(USBTX, USBRX); // tx, rx

nRF24L01P my_nrf24l01p(D11, D12, PTC5, D10, D9, D8);    // MOSI (PTD2), MISO (PTD3), SCK (PTC5), CSN (PTD0), CE (PTD5), IRQ (PTA13)

DigitalOut myled1(LED1);
DigitalOut myled2(LED2);
DigitalOut myled3(LED3);

DigitalOut IN1(D5); //PTA5
DigitalOut IN2(D4); //PTA4
DigitalOut IN3(D3); //PTA12
DigitalOut IN4(D2); //PTD4

int main() {

// The nRF24L01+ supports transfers from 1 to 32 bytes, but Sparkfun's
//  "Nordic Serial Interface Board" (http://www.sparkfun.com/products/9019)
//  only handles 4 byte transfers in the ATMega code.
#define TRANSFER_SIZE   1
#define RF_FREQUENCY    2459

    myled1 = 1;    myled2 = 1;    myled3 = 1;
    IN1 = 0;    IN2 = 0;    IN3 = 0;    IN4 = 0;

    char rxData[TRANSFER_SIZE];
    int rxDataCnt = 0;

    my_nrf24l01p.powerUp();
    my_nrf24l01p.setRfFrequency(RF_FREQUENCY);
    
    // LEDs to mark initialization
    for (int i = 0; i < 5; i++) {
        myled1 = 0;    myled2 = 1;    myled3 = 1;
        wait(0.25);
        myled1 = 1;    myled2 = 0;    myled3 = 1;
        wait(0.25);
        myled1 = 1;    myled2 = 1;    myled3 = 0;
        wait(0.25);
    }
    myled1 = 1;    myled2 = 1;    myled3 = 1;


    my_nrf24l01p.setTransferSize( TRANSFER_SIZE );

    my_nrf24l01p.setReceiveMode();
    my_nrf24l01p.enable();
    
    while (1) {
        // If we've received anything in the nRF24L01+...
        if ( my_nrf24l01p.readable() ) {

            // ...read the data into the receive buffer
            rxDataCnt = my_nrf24l01p.read( NRF24L01P_PIPE_P0, rxData, sizeof( rxData ) );
            
            switch (rxData[0]) {
                case '0':
                    myled1 = 1;    myled2 = 1;    myled3 = 1;
                    IN1 = 0;    IN2 = 0;    IN3 = 0;    IN4 = 0;
                    break;
                case '1':
                    myled1 = 0;    myled2 = 0;    myled3 = 0;
                    IN1 = 0;    IN2 = 0;    IN3 = 0;    IN4 = 0;
                    break;
                case 'A':
                    myled1 = 0;    myled2 = 1;    myled3 = 1;
                    IN1 = 1;    IN2 = 0;    IN3 = 0;    IN4 = 0;
                    break;
                case 'B':
                    myled1 = 1;    myled2 = 0;    myled3 = 1;
                    IN1 = 0;    IN2 = 0;    IN3 = 0;    IN4 = 1;
                    break;
            }
            
            // Display the receive buffer contents via the host serial link
            pc.printf("Command received: ");
            for ( int i = 0; rxDataCnt > 0; rxDataCnt--, i++ ) {
                pc.putc(rxData[i]);
            }
            pc.printf("\n\r");
        }
    }
}
