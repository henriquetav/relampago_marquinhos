#include "mbed.h"
#include "HCSR04.h"
#include <math.h>
#include <algorithm>

#define NUM_LEITURAS 9
#define SAFE_DISTANCE 20

bool obstacle_ahead(void);

DigitalOut myled(LED1);
Serial pc(USBTX,USBRX);     

HCSR04 my_hcsr04(PTB9, PTB8);    // TRIG (PTB9), ECHO (PTB8)

int main() {
    while(true) {
        obstacle_ahead();
    }
}

bool obstacle_ahead(void) {
    float distance[NUM_LEITURAS];
    for (int i = 0; i < NUM_LEITURAS; i++) {
        my_hcsr04.readEcho();
        distance[i] = my_hcsr04.getCm();
    }
    std::sort(distance,distance+NUM_LEITURAS);
    int index = ceil(NUM_LEITURAS/2.0);
    if (distance[index] <= SAFE_DISTANCE) {
        pc.printf("\tObstaculo encontrado a %.2f cm de distancia!\r\n", distance[index]);
        wait_ms(50);
        return true;
    } else 
        return false;
}